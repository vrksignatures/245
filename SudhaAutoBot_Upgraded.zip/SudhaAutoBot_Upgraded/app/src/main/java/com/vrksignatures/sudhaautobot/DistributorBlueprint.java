package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads labelled customer cards, without inferring their kind from the ID format. */
public final class DistributorBlueprint {

    public static final String PREFS_NAME = "sudha_tier1_permanent_blueprint";
    private static final String KEY_LEARNED = "blueprint_learned";
    private static final String KEY_BLACKLIST_IDS = "permanent_blacklist_ids";
    private static final String KEY_DIST_COUNT = "distributor_count";
    private static final String KEY_PERM_SCROLLS = "perm_distributor_scrolls";

    // Accepts ANY non-blank customer ID after "Customer Id:" / "Customer ID:"
    private static final Pattern CUSTOMER_LABEL = Pattern.compile("(?i)^\\s*customer\\s*id\\s*(?::\\s*(.*)|$)");
    private static final Pattern PHONE_LIKE = Pattern.compile("^\\+?\\d{10,13}$");

    private DistributorBlueprint() {
    }

    public static final class CardInfo {
        public final String customerId;
        public final String boldOrangeName;
        public final boolean isDistributor;
        public final boolean isRetailer;
        public final Rect bounds;
        public final AccessibilityNodeInfo containerNode;

        public CardInfo(String customerId, String boldOrangeName, boolean isDistributor,
                        boolean isRetailer, Rect bounds, AccessibilityNodeInfo containerNode) {
            this.customerId = customerId == null ? "" : customerId.trim().toUpperCase(Locale.ROOT);
            this.boldOrangeName = boldOrangeName == null ? "" : boldOrangeName.trim();
            this.isDistributor = isDistributor;
            this.isRetailer = isRetailer;
            this.bounds = bounds == null ? new Rect() : bounds;
            this.containerNode = containerNode;
        }

        public String normalizedName() {
            return boldOrangeName.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
    }

    public static final class Classification {
        public final Set<String> distributorIds;
        public final Set<String> distributorOwnedRetailerIds;
        public final Set<String> allBlacklistedIds;
        public final List<CardInfo> genuineRetailers;
        /** Non-null when the bottom-most visible card is a (Dist) card (triggers slow boundary scroll). */
        public final String trailingDistributorName;

        public Classification(Set<String> distributorIds, Set<String> distributorOwnedRetailerIds,
                              Set<String> allBlacklistedIds, List<CardInfo> genuineRetailers,
                              String trailingDistributorName) {
            this.distributorIds = distributorIds;
            this.distributorOwnedRetailerIds = distributorOwnedRetailerIds;
            this.allBlacklistedIds = allBlacklistedIds;
            this.genuineRetailers = genuineRetailers;
            this.trailingDistributorName = trailingDistributorName;
        }
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards) {
        return classifyOrderedCards(cards, null);
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards,
                                                      String prevPageTrailingDistName) {
        if (cards == null || cards.isEmpty()) {
            return new Classification(new LinkedHashSet<>(), new LinkedHashSet<>(),
                    new LinkedHashSet<>(), Collections.emptyList(), null);
        }
        List<UpgradeRules.Card> pure = new ArrayList<>(cards.size());
        for (CardInfo c : cards) {
            pure.add(new UpgradeRules.Card(c.customerId, c.boldOrangeName, c.isDistributor, c.isRetailer));
        }
        UpgradeRules.Classification res = UpgradeRules.classifyCardsWithCarryOver(pure, prevPageTrailingDistName);
        List<CardInfo> genuine = new ArrayList<>();
        for (int i = 0; i < cards.size(); i++) {
            if (res.genuineRetailers.contains(pure.get(i))) genuine.add(cards.get(i));
        }
        return new Classification(
                res.distributorIds,
                res.distributorOwnedRetailerIds,
                res.allBlacklistedIds,
                genuine,
                res.trailingDistributorName
        );
    }

    /** Tracks card identity and overlap, not a permanent ID blacklist. */
    public static final class CardTraversal {
        private final java.util.Map<String, String> retailerNamesById = new java.util.HashMap<>();
        private final Set<String> knownRetailers = new LinkedHashSet<>();
        private final Set<String> shadowCards = new LinkedHashSet<>();
        private final List<String> previous = new ArrayList<>();
        private int visit = Integer.MIN_VALUE;
        private String error = "";
        private List<String> provenEnd = Collections.emptyList();
        private boolean withheldLast;

        private String key(CardInfo card) {
            return (card.isDistributor ? "D:" : "R:") + card.customerId + "|" + card.normalizedName();
        }
        public String error() { return error; }
        public void reset() {
            retailerNamesById.clear(); knownRetailers.clear(); shadowCards.clear(); previous.clear();
            visit = Integer.MIN_VALUE; error = ""; provenEnd = Collections.emptyList(); withheldLast = false;
        }
        /** Called only after the scroller established it cannot move further down. */
        public boolean proveEndForWithheldCard() {
            if (!withheldLast) return false;
            provenEnd = new ArrayList<>(previous);
            withheldLast = false;
            return true;
        }
        /** Returns null if row identity or a scroll transition cannot be proven safe. */
        public Classification observe(List<CardInfo> cards, int newVisit) {
            error = "";
            if (cards == null || cards.isEmpty()) { error = "No readable cards"; return null; }
            if (visit != newVisit) { previous.clear(); provenEnd = Collections.emptyList(); visit = newVisit; }
            List<String> current = new ArrayList<>();
            for (CardInfo card : cards) {
                if (card.normalizedName().isEmpty()) { error = "Customer shop name is missing"; return null; }
                String k = key(card);
                if (current.contains(k)) { error = "Duplicate visible customer cards"; return null; }
                current.add(k);
                if (card.isRetailer) {
                    String old = retailerNamesById.get(card.customerId);
                    if (old != null && !old.equals(card.normalizedName())) {
                        error = "Customer ID appears on different retailer shops: " + card.customerId; return null;
                    }
                }
            }
            if (previous.isEmpty()) {
                CardInfo first = cards.get(0);
                if (first.isRetailer && !knownRetailers.contains(current.get(0))) {
                    error = "First visible retailer's preceding card is unknown; start at the top of the list";
                    return null;
                }
            } else if (!previous.equals(current)) {
                // Require a contiguous suffix/prefix overlap. Without it a distributor,
                // its shadow or a genuine retailer may have passed unseen.
                int overlap = 0;
                for (int n = Math.min(previous.size(), current.size()); n > 0; n--) {
                    if (previous.subList(previous.size() - n, previous.size()).equals(current.subList(0, n))) {
                        overlap = n; break;
                    }
                }
                // A viewport can move without changing which cards it contains.
                if (overlap == 0) { error = "List changed without overlapping cards; cannot verify adjacency"; return null; }
            }
            Classification raw = classifyOrderedCards(cards);
            // Retain shadow identities for as long as they overlap, even after their
            // preceding distributor has moved off the top of the screen.
            for (int i = 0; i < cards.size(); i++) {
                CardInfo c = cards.get(i);
                if (c.isRetailer && !raw.genuineRetailers.contains(c)) shadowCards.add(current.get(i));
                if (c.isRetailer) {
                    knownRetailers.add(current.get(i));
                    retailerNamesById.put(c.customerId, c.normalizedName());
                }
            }
            List<CardInfo> genuine = new ArrayList<>();
            for (CardInfo c : raw.genuineRetailers) if (!shadowCards.contains(key(c))) genuine.add(c);
            // A distributor immediately BELOW the last visible retailer is not yet known.
            // Do not open it until a successor is visible or the list end is proven.
            CardInfo last = cards.get(cards.size() - 1);
            withheldLast = !current.equals(provenEnd) && genuine.remove(last);
            previous.clear(); previous.addAll(current);
            return new Classification(raw.distributorIds, raw.distributorOwnedRetailerIds,
                    raw.allBlacklistedIds, genuine, raw.trailingDistributorName);
        }
    }

    public static final String CUSTOMER_LIST_ID = "in.vasista.suprabhat:id/customer_list";
    public static final String CARD_ID = "in.vasista.suprabhat:id/cv_parent_view";
    public static final String FILTER_ID = "in.vasista.suprabhat:id/primSecLevelsSpinner";
    public static final String SHOW_RETAILERS_ID = "in.vasista.suprabhat:id/ll_show_retailers";

    /** Prefer actual card boundaries under the customer RecyclerView. Never deduplicate by ID. */
    private static List<AccessibilityNodeInfo> cardContainers(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        AccessibilityNodeInfo list = AccessibilityTree.findByViewId(root, CUSTOMER_LIST_ID);
        if (list == null) return Collections.emptyList();
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectNodes(list, nodes, 0);
        List<AccessibilityNodeInfo> cards = new ArrayList<>();
        for (AccessibilityNodeInfo node : nodes) {
            if (CARD_ID.equals(node.getViewIdResourceName()) && node.isVisibleToUser()) cards.add(node);
        }
        return cards;
    }

    public static List<CardInfo> parseVisibleCards(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        List<AccessibilityNodeInfo> containers = new ArrayList<>(cardContainers(root));
        boolean hasList = AccessibilityTree.findByViewId(root, CUSTOMER_LIST_ID) != null;
        if (!hasList) {
            // Older layouts: pair the separate delivery/type labels only inside the same
            // single-card ancestor. Never pair labels across rows by screen geometry.
            List<AccessibilityNodeInfo> nodes = new ArrayList<>();
            collectNodes(root, nodes, 0);
            for (AccessibilityNodeInfo n : nodes) {
                if (!n.isVisibleToUser()) continue;
                String text = AccessibilityTree.textOf(n).trim().toLowerCase(Locale.ROOT);
                if (!(text.equals("delivery point") || text.contains("delivery point (dist)")
                        || text.contains("delivery point (retailer)"))) continue;
                AccessibilityNodeInfo container = findCardContainer(n);
                if (container != null && !containers.contains(container)) containers.add(container);
            }
        }
        List<CardInfo> cards = new ArrayList<>();
        for (AccessibilityNodeInfo container : containers) {
            CardInfo card = parseCard(container, hasList);
            if (card != null) cards.add(card);
        }
        Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
        return cards;
    }

    private static CardInfo parseCard(AccessibilityNodeInfo container, boolean liveCard) {
        List<String> texts = new ArrayList<>();
        if (liveCard) collectCardTexts(container, texts, 0);
        else collectTexts(container, texts, 0);
        boolean dist = false, retailer = false, delivery = false;
        for (String raw : texts) {
            String t = raw.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
            if (t.equals("delivery point") || t.startsWith("delivery point (")) delivery = true;
            if (t.equals("(dist)") || t.contains("delivery point (dist)")) dist = true;
            if (t.equals("(retailer)") || t.contains("delivery point (retailer)")) retailer = true;
        }
        if (!delivery || dist == retailer) return null;
        String id = "", name = "";
        for (int i = 0; i < texts.size(); i++) {
            Matcher m = CUSTOMER_LABEL.matcher(texts.get(i));
            if (!m.matches()) continue;
            String inline = m.group(1);
            int nameAt;
            if (inline != null && !inline.trim().isEmpty()) {
                id = inline.trim(); nameAt = i + 1;
            } else {
                if (i + 1 >= texts.size()) return null;
                id = texts.get(i + 1).trim(); nameAt = i + 2;
                // In legacy trees a following-line shop name is not evidence of an ID.
                if (!liveCard && extractCustomerId(container).isEmpty()) return null;
            }
            if (nameAt < texts.size()) name = texts.get(nameAt).trim();
            break;
        }
        if (id.isEmpty() || name.isEmpty()) return null;
        Rect rect = new Rect(); container.getBoundsInScreen(rect);
        return new CardInfo(id, name, dist, retailer, rect, container);
    }

    /** Section 5 Rule 2: Finds the filter dropdown to the left of "Show Retailers". */
    public static Object[] findFilterDropdown(AccessibilityNodeInfo root) {
        if (root == null) return null;
        AccessibilityNodeInfo spinner = AccessibilityTree.findByViewId(root, FILTER_ID);
        if (spinner != null) {
            List<String> labels = new ArrayList<>(); collectTexts(spinner, labels, 0);
            for (String label : labels) if ("All Distributors".equalsIgnoreCase(label.trim()))
                return new Object[]{spinner, "All Distributors"};
            for (String label : labels) if (!label.trim().isEmpty()) return new Object[]{spinner, label.trim()};
            return null;
        }
        AccessibilityNodeInfo allDist = AccessibilityTree.findExact(root, "All Distributors");
        return allDist == null ? null : new Object[]{allDist, "All Distributors"};
    }

    /** Find an All Distributors option only inside a list popup, never in a customer card. */
    public static AccessibilityNodeInfo findFilterOption(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>(); collectNodes(root, nodes, 0);
        for (AccessibilityNodeInfo node : nodes) {
            if (!node.isVisibleToUser() || !"All Distributors".equalsIgnoreCase(AccessibilityTree.textOf(node).trim())) continue;
            AccessibilityNodeInfo cursor = node, clickable = null;
            for (int hop = 0; cursor != null && hop < 12; hop++, cursor = cursor.getParent()) {
                String id = cursor.getViewIdResourceName();
                if (CARD_ID.equals(id) || CUSTOMER_LIST_ID.equals(id) || FILTER_ID.equals(id)) break;
                String cls = cursor.getClassName() == null ? "" : cursor.getClassName().toString().toLowerCase(Locale.ROOT);
                if (cls.contains("listview") || cls.contains("recyclerview")) return clickable != null ? clickable : node;
                if (clickable == null && cursor.isClickable()) clickable = cursor;
            }
        }
        return null;
    }

    // --------------------------------------------------- Tier 1 Persistence

    public static boolean isLearned(Context context) {
        return prefs(context).getBoolean(KEY_LEARNED, false);
    }

    public static Set<String> permanentBlacklist(Context context) {
        Set<String> stored = prefs(context).getStringSet(KEY_BLACKLIST_IDS, Collections.emptySet());
        return stored == null ? Collections.emptySet() : new LinkedHashSet<>(stored);
    }

    public static int permDistributorScrolls(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_PERM_SCROLLS, 0));
    }

    public static void addBlacklistedIds(Context context, Set<String> ids) {
        if (ids == null || ids.isEmpty()) return;
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(ids);
        prefs(context).edit().putStringSet(KEY_BLACKLIST_IDS, merged).apply();
    }

    public static void saveLearnedBlueprint(Context context, Classification c, int permScrolls) {
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(c.allBlacklistedIds);
        prefs(context).edit()
                .putBoolean(KEY_LEARNED, true)
                .putStringSet(KEY_BLACKLIST_IDS, merged)
                .putInt(KEY_DIST_COUNT, Math.max(c.distributorIds.size(), prefs(context).getInt(KEY_DIST_COUNT, 0)))
                .putInt(KEY_PERM_SCROLLS, Math.max(0, permScrolls))
                .apply();
    }

    public static void resetDistributorHistory(Context context) {
        prefs(context).edit().clear().apply();
    }

    public static String statusSummary(Context context) {
        SharedPreferences p = prefs(context);
        if (!p.getBoolean(KEY_LEARNED, false)) {
            return "Tier 1 Permanent Blueprint: Not learned yet (auto-learns on next START)";
        }
        int dists = p.getInt(KEY_DIST_COUNT, 0);
        int blacklisted = permanentBlacklist(context).size();
        int scrolls = permDistributorScrolls(context);
        return "Tier 1 Permanent Blueprint: LEARNED · Distributors: " + dists
                + " · Blacklisted IDs: " + blacklisted + " · Top scrolls: " + scrolls;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // --------------------------------------------------------- Tree helpers

    private static AccessibilityNodeInfo findCardContainer(AccessibilityNodeInfo anchor) {
        AccessibilityNodeInfo cur = anchor;
        AccessibilityNodeInfo best = null;
        for (int hop = 0; cur != null && hop < 14; hop++) {
            if (cur.isScrollable()) break;
            List<String> texts = new ArrayList<>(); collectTexts(cur, texts, 0);
            int deliveries = 0, ids = 0; boolean type = false;
            for (String s : texts) {
                String low = s.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
                if (low.equals("delivery point") || low.startsWith("delivery point (")) deliveries++;
                if (low.equals("(dist)") || low.equals("(retailer)")
                        || low.contains("delivery point (dist)") || low.contains("delivery point (retailer)")) type = true;
                if (CUSTOMER_LABEL.matcher(s).matches()) ids++;
            }
            if (deliveries > 1 || ids > 1) break;
            if (deliveries == 1 && ids == 1 && type) {
                if (best == null) best = cur;
                if (cur.isClickable()) return cur;
            }
            cur = cur.getParent();
        }
        return best;
    }

    private static String extractCustomerId(AccessibilityNodeInfo container) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectNodes(container, nodes, 0);
        for (int i = 0; i < nodes.size(); i++) {
            AccessibilityNodeInfo label = nodes.get(i);
            Matcher m = CUSTOMER_LABEL.matcher(AccessibilityTree.textOf(label));
            if (!m.matches()) continue;
            String value = m.group(1);
            if (value != null && !value.trim().isEmpty()) return value.trim().toUpperCase(Locale.ROOT);
            Rect labelBounds = new Rect();
            label.getBoundsInScreen(labelBounds);
            for (int j = i + 1; j < nodes.size(); j++) {
                AccessibilityNodeInfo candidate = nodes.get(j);
                String next = AccessibilityTree.textOf(candidate).trim();
                if (next.isEmpty()) continue;
                Rect b = new Rect();
                candidate.getBoundsInScreen(b);
                if (labelBounds.height() > 0 && b.height() > 0
                        && Math.abs(b.centerY() - labelBounds.centerY()) <= Math.max(2, labelBounds.height() / 2)
                        && b.left >= labelBounds.left
                        && !CUSTOMER_LABEL.matcher(next).matches()
                        && !next.toLowerCase(Locale.ROOT).contains("delivery point")) {
                    return next.toUpperCase(Locale.ROOT);
                }
                // Do not take a shop name on a subsequent line as the missing ID.
                break;
            }
        }
        return "";
    }

    private static String extractBoldOrangeName(List<String> texts, String id) {
        String fallback = "";
        for (String raw : texts) {
            String t = raw.trim();
            if (t.isEmpty() || t.equalsIgnoreCase(id)) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.contains("delivery point") || CUSTOMER_LABEL.matcher(t).matches()
                    || low.startsWith("rtr_") || low.startsWith("s.o(") || low.startsWith("p.r.")
                    || low.startsWith("total customers") || PHONE_LIKE.matcher(t).matches()) continue;
            if (fallback.isEmpty()) fallback = t;
            if (t.equals(t.toUpperCase(Locale.ROOT)) && t.matches(".*[A-Z].*")) return t;
        }
        return fallback;
    }

    /** Count card blocks even if their labels or IDs cannot be parsed. */
    public static int visibleAnchorCount(AccessibilityNodeInfo root) {
        if (root == null) return 0;
        if (AccessibilityTree.findByViewId(root, CUSTOMER_LIST_ID) != null) return cardContainers(root).size();
        List<AccessibilityNodeInfo> all = new ArrayList<>(); collectNodes(root, all, 0);
        int count = 0;
        for (AccessibilityNodeInfo node : all) {
            if (!node.isVisibleToUser()) continue;
            String text = AccessibilityTree.textOf(node).trim().toLowerCase(Locale.ROOT);
            if (text.equals("delivery point") || text.contains("delivery point (dist)")
                    || text.contains("delivery point (retailer)")) count++;
        }
        return count;
    }

    // Preserve an explicitly empty TextView: otherwise the shop name could be
    // mistaken for an ID when a card is only partially populated.
    private static void collectCardTexts(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 20 || out.size() > 120) return;
        CharSequence text = node.getText();
        if (text != null) out.add(text.toString());
        else if (node.getChildCount() == 0 && node.getContentDescription() != null)
            out.add(node.getContentDescription().toString());
        for (int i = 0; i < node.getChildCount(); i++) collectCardTexts(node.getChild(i), out, depth + 1);
    }

    private static void collectTexts(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 20 || out.size() > 120) return;
        String t = AccessibilityTree.textOf(node);
        if (!t.isEmpty()) out.add(t);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectTexts(node.getChild(i), out, depth + 1);
    }

    private static void collectNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out, int depth) {
        if (node == null || depth > 45 || out.size() > 800) return;
        out.add(node);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectNodes(node.getChild(i), out, depth + 1);
    }
}
