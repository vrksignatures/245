package com.vrksignatures.sudhaautobot;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Rect;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads labelled customer cards, without inferring their kind from the ID format. */
public final class DistributorBlueprint {

    public static final String PREFS_NAME = "sudha_tier1_permanent_blueprint";
    private static final String KEY_LEARNED = "blueprint_learned";
    private static final String KEY_BLACKLIST_IDS = "permanent_blacklist_ids";
    private static final String KEY_DIST_COUNT = "distributor_count";
    private static final String KEY_PERM_SCROLLS = "perm_distributor_scrolls";

    // Accepts ANY non-blank customer ID after "Customer Id:" / "Customer ID:"
    private static final Pattern CUSTOMER_LABEL = Pattern.compile("(?i)^\\s*customer\\s*id\\s*(?::\\s*(.*)|$)");
    private static final Pattern PHONE_LIKE = Pattern.compile("^\\+?\\d{10,13}$");

    private DistributorBlueprint() {
    }

    public static final class CardInfo {
        public final String customerId;
        public final String boldOrangeName;
        public final boolean isDistributor;
        public final boolean isRetailer;
        public final Rect bounds;
        public final AccessibilityNodeInfo containerNode;

        public CardInfo(String customerId, String boldOrangeName, boolean isDistributor,
                        boolean isRetailer, Rect bounds, AccessibilityNodeInfo containerNode) {
            this.customerId = customerId == null ? "" : customerId.trim().toUpperCase(Locale.ROOT);
            this.boldOrangeName = boldOrangeName == null ? "" : boldOrangeName.trim();
            this.isDistributor = isDistributor;
            this.isRetailer = isRetailer;
            this.bounds = bounds == null ? new Rect() : bounds;
            this.containerNode = containerNode;
        }

        public String normalizedName() {
            return boldOrangeName.trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
        }
    }

    public static final class Classification {
        public final Set<String> distributorIds;
        public final Set<String> distributorOwnedRetailerIds;
        public final Set<String> allBlacklistedIds;
        public final List<CardInfo> genuineRetailers;
        /** Non-null when the bottom-most visible card is a (Dist) card (triggers slow boundary scroll). */
        public final String trailingDistributorName;

        public Classification(Set<String> distributorIds, Set<String> distributorOwnedRetailerIds,
                              Set<String> allBlacklistedIds, List<CardInfo> genuineRetailers,
                              String trailingDistributorName) {
            this.distributorIds = distributorIds;
            this.distributorOwnedRetailerIds = distributorOwnedRetailerIds;
            this.allBlacklistedIds = allBlacklistedIds;
            this.genuineRetailers = genuineRetailers;
            this.trailingDistributorName = trailingDistributorName;
        }
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards) {
        return classifyOrderedCards(cards, null);
    }

    public static Classification classifyOrderedCards(List<CardInfo> cards,
                                                      String prevPageTrailingDistName) {
        if (cards == null || cards.isEmpty()) {
            return new Classification(new LinkedHashSet<>(), new LinkedHashSet<>(),
                    new LinkedHashSet<>(), Collections.emptyList(), null);
        }
        List<UpgradeRules.Card> pure = new ArrayList<>(cards.size());
        for (CardInfo c : cards) {
            pure.add(new UpgradeRules.Card(c.customerId, c.boldOrangeName, c.isDistributor, c.isRetailer));
        }
        UpgradeRules.Classification res = UpgradeRules.classifyCardsWithCarryOver(pure, prevPageTrailingDistName);
        List<CardInfo> genuine = new ArrayList<>();
        for (int i = 0; i < cards.size(); i++) {
            if (res.genuineRetailers.contains(pure.get(i))) genuine.add(cards.get(i));
        }
        return new Classification(
                res.distributorIds,
                res.distributorOwnedRetailerIds,
                res.allBlacklistedIds,
                genuine,
                res.trailingDistributorName
        );
    }

    /** Parse visible labelled cards in display order. An unreadable card is reported by
     * comparing this result with {@link #visibleAnchorCount}, never guessed geometrically. */
    public static List<CardInfo> parseVisibleCards(AccessibilityNodeInfo root) {
        if (root == null) return Collections.emptyList();
        List<AccessibilityNodeInfo> allNodes = new ArrayList<>();
        collectNodes(root, allNodes, 0);

        List<AccessibilityNodeInfo> anchors = new ArrayList<>();
        for (AccessibilityNodeInfo n : allNodes) {
            if (!n.isVisibleToUser()) continue;
            String t = AccessibilityTree.textOf(n).toLowerCase(Locale.ROOT);
            if (t.contains("delivery point (dist)") || t.contains("delivery point (retailer)")) {
                anchors.add(n);
            }
        }

        List<CardInfo> cards = new ArrayList<>();
        Set<String> seen = new LinkedHashSet<>();

        for (AccessibilityNodeInfo anchor : anchors) {
            String anchorLower = AccessibilityTree.textOf(anchor).toLowerCase(Locale.ROOT);
            boolean isDist = anchorLower.contains("(dist)");
            boolean isRet = !isDist && anchorLower.contains("(retailer)");

            Rect anchorRect = new Rect();
            anchor.getBoundsInScreen(anchorRect);

            // Strategy 1: Deep ancestor container search (up to 14 hops)
            AccessibilityNodeInfo container = findCardContainer(anchor);
            String id = "";
            String name = "";
            Rect cardRect = new Rect(anchorRect);

            if (container != null) {
                container.getBoundsInScreen(cardRect);
                List<String> texts = new ArrayList<>();
                collectTexts(container, texts, 0);
                id = extractCustomerId(container);
                name = extractBoldOrangeName(texts, id);
            }

            // Strategy 2: Geometric same-row pairing fallback if ancestor container missed Customer Id
            // No unverified geometric pairing: an ID in another row is not proof of
            // identity. A partially exposed card must be read again before scrolling.


            if (id.isEmpty()) continue;
            if (cardRect.width() <= 0 || cardRect.height() <= 0) cardRect = anchorRect;

            String key = id + "|" + (isDist ? "D" : "R");
            if (!seen.add(key)) continue;

            cards.add(new CardInfo(id, name, isDist, isRet, cardRect, container));
        }

        Collections.sort(cards, Comparator.comparingInt(c -> c.bounds.top));
        return cards;
    }

    /** Section 5 Rule 2: Finds the filter dropdown to the left of "Show Retailers". */
    public static Object[] findFilterDropdown(AccessibilityNodeInfo root) {
        if (root == null) return null;
        AccessibilityNodeInfo allDist = AccessibilityTree.findExact(root, "All Distributors");
        if (allDist != null) return new Object[]{allDist, "All Distributors"};

        // A nearby text node is not proof that it is the filter. Never click a
        // customer card just because the real dropdown is off-screen.
        return null;
    }

    // --------------------------------------------------- Tier 1 Persistence

    public static boolean isLearned(Context context) {
        return prefs(context).getBoolean(KEY_LEARNED, false);
    }

    public static Set<String> permanentBlacklist(Context context) {
        Set<String> stored = prefs(context).getStringSet(KEY_BLACKLIST_IDS, Collections.emptySet());
        return stored == null ? Collections.emptySet() : new LinkedHashSet<>(stored);
    }

    public static int permDistributorScrolls(Context context) {
        return Math.max(0, prefs(context).getInt(KEY_PERM_SCROLLS, 0));
    }

    public static void addBlacklistedIds(Context context, Set<String> ids) {
        if (ids == null || ids.isEmpty()) return;
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(ids);
        prefs(context).edit().putStringSet(KEY_BLACKLIST_IDS, merged).apply();
    }

    public static void saveLearnedBlueprint(Context context, Classification c, int permScrolls) {
        Set<String> merged = new LinkedHashSet<>(permanentBlacklist(context));
        merged.addAll(c.allBlacklistedIds);
        prefs(context).edit()
                .putBoolean(KEY_LEARNED, true)
                .putStringSet(KEY_BLACKLIST_IDS, merged)
                .putInt(KEY_DIST_COUNT, Math.max(c.distributorIds.size(), prefs(context).getInt(KEY_DIST_COUNT, 0)))
                .putInt(KEY_PERM_SCROLLS, Math.max(0, permScrolls))
                .apply();
    }

    public static void resetDistributorHistory(Context context) {
        prefs(context).edit().clear().apply();
    }

    public static String statusSummary(Context context) {
        SharedPreferences p = prefs(context);
        if (!p.getBoolean(KEY_LEARNED, false)) {
            return "Tier 1 Permanent Blueprint: Not learned yet (auto-learns on next START)";
        }
        int dists = p.getInt(KEY_DIST_COUNT, 0);
        int blacklisted = permanentBlacklist(context).size();
        int scrolls = permDistributorScrolls(context);
        return "Tier 1 Permanent Blueprint: LEARNED · Distributors: " + dists
                + " · Blacklisted IDs: " + blacklisted + " · Top scrolls: " + scrolls;
    }

    private static SharedPreferences prefs(Context context) {
        return context.getApplicationContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
    }

    // --------------------------------------------------------- Tree helpers

    private static AccessibilityNodeInfo findCardContainer(AccessibilityNodeInfo anchor) {
        AccessibilityNodeInfo cur = anchor;
        AccessibilityNodeInfo best = null;
        for (int hop = 0; cur != null && hop < 14; hop++) {
            List<String> texts = new ArrayList<>();
            collectTexts(cur, texts, 0);
            int dpCount = 0;
            boolean hasId = false;
            for (String s : texts) {
                String low = s.toLowerCase(Locale.ROOT);
                if (low.contains("delivery point (")) dpCount++;
                if (CUSTOMER_LABEL.matcher(s).matches()) hasId = true;
            }
            if (dpCount > 1 || cur.isScrollable()) break;
            if (dpCount == 1 && hasId) {
                if (best == null) best = cur;
                if (cur.isClickable()) return cur;
            }
            cur = cur.getParent();
        }
        return best;
    }

    private static String extractCustomerId(AccessibilityNodeInfo container) {
        List<AccessibilityNodeInfo> nodes = new ArrayList<>();
        collectNodes(container, nodes, 0);
        for (int i = 0; i < nodes.size(); i++) {
            AccessibilityNodeInfo label = nodes.get(i);
            Matcher m = CUSTOMER_LABEL.matcher(AccessibilityTree.textOf(label));
            if (!m.matches()) continue;
            String value = m.group(1);
            if (value != null && !value.trim().isEmpty()) return value.trim().toUpperCase(Locale.ROOT);
            Rect labelBounds = new Rect();
            label.getBoundsInScreen(labelBounds);
            for (int j = i + 1; j < nodes.size(); j++) {
                AccessibilityNodeInfo candidate = nodes.get(j);
                String next = AccessibilityTree.textOf(candidate).trim();
                if (next.isEmpty()) continue;
                Rect b = new Rect();
                candidate.getBoundsInScreen(b);
                if (labelBounds.height() > 0 && b.height() > 0
                        && Math.abs(b.centerY() - labelBounds.centerY()) <= Math.max(2, labelBounds.height() / 2)
                        && b.left >= labelBounds.left
                        && !CUSTOMER_LABEL.matcher(next).matches()
                        && !next.toLowerCase(Locale.ROOT).contains("delivery point")) {
                    return next.toUpperCase(Locale.ROOT);
                }
                // Do not take a shop name on a subsequent line as the missing ID.
                break;
            }
        }
        return "";
    }

    private static String extractBoldOrangeName(List<String> texts, String id) {
        String fallback = "";
        for (String raw : texts) {
            String t = raw.trim();
            if (t.isEmpty() || t.equalsIgnoreCase(id)) continue;
            String low = t.toLowerCase(Locale.ROOT);
            if (low.contains("delivery point") || CUSTOMER_LABEL.matcher(t).matches()
                    || low.startsWith("rtr_") || low.startsWith("s.o(") || low.startsWith("p.r.")
                    || low.startsWith("total customers") || PHONE_LIKE.matcher(t).matches()) continue;
            if (fallback.isEmpty()) fallback = t;
            if (t.equals(t.toUpperCase(Locale.ROOT)) && t.matches(".*[A-Z].*")) return t;
        }
        return fallback;
    }

    /** An unreadable card must not silently disappear from a scrolling decision. */
    public static int visibleAnchorCount(AccessibilityNodeInfo root) {
        List<AccessibilityNodeInfo> all = new ArrayList<>();
        collectNodes(root, all, 0);
        int count = 0;
        for (AccessibilityNodeInfo node : all) {
            if (!node.isVisibleToUser()) continue;
            String text = AccessibilityTree.textOf(node).toLowerCase(Locale.ROOT);
            if (text.contains("delivery point (dist)") || text.contains("delivery point (retailer)")) count++;
        }
        return count;
    }

    private static void collectTexts(AccessibilityNodeInfo node, List<String> out, int depth) {
        if (node == null || depth > 20 || out.size() > 120) return;
        String t = AccessibilityTree.textOf(node);
        if (!t.isEmpty()) out.add(t);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectTexts(node.getChild(i), out, depth + 1);
    }

    private static void collectNodes(AccessibilityNodeInfo node, List<AccessibilityNodeInfo> out, int depth) {
        if (node == null || depth > 45 || out.size() > 800) return;
        out.add(node);
        int count = node.getChildCount();
        for (int i = 0; i < count; i++) collectNodes(node.getChild(i), out, depth + 1);
    }
}
