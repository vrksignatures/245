package com.vrksignatures.sudhaautobot;

/** Customer ID handling. Card type is determined from the delivery-point label,
 * not from an ID prefix. Legacy SMR scanners below are retained for historical tests;
 * the service's list and details paths do not use them. */
public final class RetailerPolicy {
    /** Number of retailers expected per day; used for the panel progress bar. */
    public static final int EXPECTED_RETAILER_COUNT = 125;

    /** Anchored: the whole token must be SMR + digits. */
    private static final java.util.regex.Pattern EXACT_ID =
            java.util.regex.Pattern.compile("SMR[0-9]{1,6}");

    private RetailerPolicy() {
    }

    /**
     * Accepts ANY non-blank exact Customer ID (SMR*, numeric 1234, alphabetic ABCD,
     * alphanumeric ABC-17, spaced R 204). Never assumes SMR prefix.
     */
    public static boolean isValidCustomerId(String value) {
        if (value == null) return false;
        String trimmed = value.trim();
        return !trimmed.isEmpty();
    }

    /** Preserves exact arbitrary Customer ID verbatim (trimmed, uppercase); never prepends SMR. */
    public static String normalizeAnyId(String raw) {
        if (raw == null) return null;
        String trimmed = raw.trim().toUpperCase(java.util.Locale.ROOT);
        return isValidCustomerId(trimmed) ? trimmed : null;
    }


    /** Exact match first; tolerate whitespace in a typed start point only when unique on the page. */
    public static int findStartId(java.util.List<String> ids, String typed) {
        String target = normalizeAnyId(typed);
        if (target == null || ids == null) return -1;
        for (int i = 0; i < ids.size(); i++) {
            if (target.equals(normalizeAnyId(ids.get(i)))) return i;
        }
        String compact = target.replaceAll("\\s+", "");
        int found = -1;
        for (int i = 0; i < ids.size(); i++) {
            String id = normalizeAnyId(ids.get(i));
            if (id != null && compact.equals(id.replaceAll("\\s+", ""))) {
                if (found >= 0) return -1;
                found = i;
            }
        }
        return found;
    }

    /** Match the customer header or a labelled customer ID, never a substring or distributor line. */
    public static boolean detailsShowsId(String text, String expected) {
        String id = normalizeAnyId(expected);
        if (text == null || id == null) return false;
        for (String line : text.split("\\r?\\n")) {
            String lower = line.toLowerCase(java.util.Locale.ROOT);
            if (lower.contains("distributor")) continue;
            java.util.regex.Matcher label = java.util.regex.Pattern
                    .compile("(?i)^\\s*customer\\s*id\\s*:\\s*(.*?)\\s*$").matcher(line);
            if (label.matches() && id.equals(normalizeAnyId(label.group(1)))) return true;
            java.util.regex.Matcher parens = java.util.regex.Pattern.compile("\\(([^()]*)\\)").matcher(line);
            while (parens.find()) {
                if (id.equals(normalizeAnyId(parens.group(1)))) return true;
            }
        }
        return false;
    }

    /** True only for an exact {@code SMR<digits>} token. */
    public static boolean isRetailerId(String value) {
        if (value == null) return false;
        return EXACT_ID.matcher(value.trim()).matches();
    }

    /**
     * Regex used to scan free text / node labels for embedded retailer tokens.
     * The guards reject tokens glued to other letters or digits, so {@code SMR12}
     * inside {@code SMRSMR12} or {@code ESMR12} is not picked up.
     */
    public static java.util.regex.Pattern embeddedPattern() {
        return java.util.regex.Pattern.compile("(?<![A-Z0-9])SMR[0-9]{1,6}(?![A-Z0-9])");
    }

    /** Distributor tokens, matched only to make sure we steer clear of them. */
    public static java.util.regex.Pattern distributorPattern() {
        return java.util.regex.Pattern.compile("(?<![A-Z0-9])SM[0-9]{1,6}(?![A-Z0-9])");
    }

    /** Normalises user input such as " smr012 " into "SMR012"; null when invalid. */
    public static String normalize(String raw) {
        if (raw == null) return null;
        String trimmed = raw.trim().toUpperCase(java.util.Locale.ROOT);
        return isRetailerId(trimmed) ? trimmed : null;
    }

    /** Extracts the numeric part of a valid id, or -1. */
    public static int numericPart(String id) {
        if (!isRetailerId(id)) return -1;
        try {
            return Integer.parseInt(id.substring(3));
        } catch (NumberFormatException ignored) {
            return -1;
        }
    }
}
