import com.vrksignatures.sudhaautobot.RetailerPolicy;
import com.vrksignatures.sudhaautobot.RetailerSequence;
import com.vrksignatures.sudhaautobot.ScrollMemory;
import com.vrksignatures.sudhaautobot.StartPoint;
import com.vrksignatures.sudhaautobot.UpgradeRules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * End-to-end JVM verification of ALL upgraded behaviors, including the exact screen recording
 * scenario (SMR2157 typed as Last done ID -> next card 20173 Abhishek Enterprises -> 19863 -> 19824).
 */
public final class UpgradeSelfTest {

    private static int checks;

    private static void check(boolean cond, String msg) {
        checks++;
        if (!cond) throw new AssertionError("FAIL: " + msg);
    }

    public static void main(String[] args) {
        System.out.println("== UpgradeSelfTest ==");

        // 1. Arbitrary Customer IDs accepted verbatim
        check(RetailerPolicy.isValidCustomerId("20173"), "numeric 20173 valid");
        check(RetailerPolicy.isValidCustomerId("19863"), "numeric 19863 valid");
        check(RetailerPolicy.isValidCustomerId("ABCD"), "alphabetic ABCD valid");
        check(RetailerPolicy.isValidCustomerId("ABC-17"), "hyphenated ABC-17 valid");
        check(RetailerPolicy.isValidCustomerId("R 204"), "spaced R 204 valid");
        check(RetailerPolicy.isValidCustomerId("SMR2157"), "SMR2157 valid");
        check(!RetailerPolicy.isValidCustomerId("   "), "blank rejected");
        check("20173".equals(RetailerPolicy.normalizeAnyId(" 20173 ")), "20173 stays 20173, never SMR20173");
        check("ABC-17".equals(RetailerPolicy.normalizeAnyId(" abc-17 ")), "ABC-17 preserved");

        // 2. EXACT VIDEO SCENARIO (00:57): SMR2157 typed in Last done ID, 20173 right below it!
        List<String> videoScreen = Arrays.asList("SMR2160", "SMR2159", "SMR2158", "SMR2157", "20173");
        Set<String> done = new LinkedHashSet<>();
        StartPoint.Seeker seeker = new StartPoint.Seeker("SMR2157", "typed on the panel");
        StartPoint.Book book = new StartPoint.Book() {
            @Override public boolean isProcessed(String id) { return done.contains(id); }
            @Override public String lastHandled() { return "SMR2157"; }
            @Override public boolean markDoneBefore(String id, String why) { return done.add(id); }
        };
        StartPoint.Seeker.Outcome seekOut = seeker.seesAnyId(videoScreen, book);
        check(seekOut == StartPoint.Seeker.Outcome.REACHED, "Seeker reaches SMR2157 immediately on video screen");
        check(done.contains("SMR2157") && !done.contains("20173"), "SMR2157 marked done, 20173 NOT marked done");

        RetailerSequence seq = new RetailerSequence();
        RetailerSequence.Decision nextAfter2157 = seq.decideAnyId(videoScreen, "SMR2157", done::contains);
        check(nextAfter2157.action == RetailerSequence.Action.OPEN && "20173".equals(nextAfter2157.id),
                "Video scenario: MUST open 20173 (Abhishek Enterprises) immediately after SMR2157!");

        // Next page with ONLY numeric IDs (19863, 19824, 19823, 19821)
        List<String> numericPage = Arrays.asList("19863", "19824", "19823", "19821");
        done.add("20173");
        RetailerSequence.Decision nextNumeric = seq.decideAnyId(numericPage, "20173", done::contains);
        check(nextNumeric.action == RetailerSequence.Action.OPEN && "19863".equals(nextNumeric.id),
                "Numeric page: MUST open 19863 right after 20173!");

        // 3. ScrollMemory.nextAnyId on pure numeric-ID page (must NOT falsely declare FURTHER_DOWN)
        ScrollMemory.Seek smSeek = new ScrollMemory.Seek("20173", 5);
        smSeek.burst();
        ScrollMemory.Move mv = smSeek.nextAnyId(numericPage, done::contains, "19863@100;19824@200;");
        check(mv == ScrollMemory.Move.BACK, "ScrollMemory sees unhandled numeric IDs and looks UP (not FURTHER_DOWN)");

        // 4. Same-page Ranjana Dist SM65 + adjacent Retailer 65 skipped; Mushkan Kirana is True Retailer #1
        List<UpgradeRules.Card> list1 = Arrays.asList(
                new UpgradeRules.Card("SM65", "RANJANA YADVENDU", true, false),
                new UpgradeRules.Card("65", "RANJANA YADVENDU", false, true),
                new UpgradeRules.Card("SMR2255", "MUSHKAN KIRANA", false, true),
                new UpgradeRules.Card("1234", "OM KIRANA", false, true)
        );
        UpgradeRules.Classification c1 = UpgradeRules.classifyCards(list1);
        check(c1.allBlacklistedIds.contains("SM65") && c1.allBlacklistedIds.contains("65"), "Dist SM65 + shadow 65 blacklisted");
        check(c1.genuineRetailers.size() == 2 && "SMR2255".equals(c1.genuineRetailers.get(0).customerId),
                "SMR2255 is True Retailer #1");

        // 5. Cross-page Dist-to-shadow boundary carry-over
        List<UpgradeRules.Card> page1 = Arrays.asList(
                new UpgradeRules.Card("101", "ALPHA SHOP", false, true),
                new UpgradeRules.Card("SM100", "NORTH DAIRY", true, false)
        );
        UpgradeRules.Classification cp1 = UpgradeRules.classifyCards(page1);
        check("north dairy".equals(cp1.trailingDistributorName), "Page 1 detects trailing Dist at bottom");

        List<UpgradeRules.Card> page2 = Arrays.asList(
                new UpgradeRules.Card("778812", "NORTH DAIRY", false, true),
                new UpgradeRules.Card("ABC-17", "VILLAGE SHOP", false, true),
                new UpgradeRules.Card("9999", "NORTH DAIRY", false, true)
        );
        UpgradeRules.Classification cp2 = UpgradeRules.classifyCardsWithCarryOver(page2, cp1.trailingDistributorName);
        check(cp2.allBlacklistedIds.contains("778812"), "Cross-page immediate shadow 778812 boycotted");
        check(!cp2.allBlacklistedIds.contains("ABC-17") && !cp2.allBlacklistedIds.contains("9999"),
                "Genuine ABC-17 and later same-name 9999 kept");

        // 6. Employee's Chance scatter & Customer Demand pack math
        Map<Integer, Integer> plan = UpgradeRules.generateScatteredPlan("2026-11-20", 10000, 15, 125);
        int sum = 0;
        List<Integer> keys = new ArrayList<>(plan.keySet());
        for (int v : plan.values()) sum += v;
        check(plan.size() == 15 && sum == 10000 && keys.get(keys.size() - 1) > 30, "Scatter plan valid");

        int[] delta = UpgradeRules.resolvePackDelta(1000, 0, 4);
        check(delta != null && delta[0] == 500 && delta[1] == 6, "COW 500 ML 4 -> 6");

        System.out.println("CHECKS " + checks + " passed");
    }
}
