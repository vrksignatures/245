import com.vrksignatures.sudhaautobot.RetailerPolicy;
import com.vrksignatures.sudhaautobot.RetailerSequence;
import com.vrksignatures.sudhaautobot.UpgradeRules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public final class UpgradeSelfTest {

    private static int checks;

    private static void check(boolean cond, String msg) {
        checks++;
        if (!cond) throw new AssertionError("FAIL: " + msg);
    }

    public static void main(String[] args) {
        System.out.println("== UpgradeSelfTest ==");

        // 1. Arbitrary Customer IDs accepted verbatim (numeric, alpha, alphanumeric, hyphenated, spaced)
        check(RetailerPolicy.isValidCustomerId("1234"), "numeric 1234 valid");
        check(RetailerPolicy.isValidCustomerId("ABCD"), "alphabetic ABCD valid");
        check(RetailerPolicy.isValidCustomerId("ABC-17"), "hyphenated ABC-17 valid");
        check(RetailerPolicy.isValidCustomerId("R 204"), "spaced R 204 valid");
        check(RetailerPolicy.isValidCustomerId("SMR1024"), "SMR1024 valid");
        check(!RetailerPolicy.isValidCustomerId("   "), "blank rejected");
        check("1234".equals(RetailerPolicy.normalizeAnyId(" 1234 ")), "1234 stays 1234, never SMR1234");
        check("ABC-17".equals(RetailerPolicy.normalizeAnyId(" abc-17 ")), "ABC-17 preserved");

        // 2. Displayed-order sequence with arbitrary non-SMR IDs
        RetailerSequence seq = new RetailerSequence();
        List<String> mixedIds = Arrays.asList("SMR900", "12345", "ABCD", "ABC-17");
        RetailerSequence.Decision d1 = seq.decideAnyId(mixedIds, "SMR900", id -> false);
        check(d1.action == RetailerSequence.Action.OPEN && "12345".equals(d1.id), "12345 comes after SMR900");
        RetailerSequence.Decision d2 = seq.decideAnyId(mixedIds, "12345", id -> false);
        check(d2.action == RetailerSequence.Action.OPEN && "ABCD".equals(d2.id), "ABCD comes after 12345");
        RetailerSequence.Decision d3 = seq.decideAnyId(mixedIds, "ABCD", id -> false);
        check(d3.action == RetailerSequence.Action.OPEN && "ABC-17".equals(d3.id), "ABC-17 comes after ABCD");

        // 3. Same-page Ranjana Dist SM65 + adjacent Retailer 65 skipped; Mushkan Kirana is True Retailer #1
        List<UpgradeRules.Card> list1 = Arrays.asList(
                new UpgradeRules.Card("SM65", "RANJANA YADVENDU", true, false),
                new UpgradeRules.Card("65", "RANJANA YADVENDU", false, true),
                new UpgradeRules.Card("SMR2255", "MUSHKAN KIRANA", false, true),
                new UpgradeRules.Card("1234", "OM KIRANA", false, true)
        );
        UpgradeRules.Classification c1 = UpgradeRules.classifyCards(list1);
        check(c1.allBlacklistedIds.contains("SM65"), "SM65 blacklisted");
        check(c1.allBlacklistedIds.contains("65"), "Adjacent same-name retailer 65 blacklisted");
        check(c1.genuineRetailers.size() == 2 && "SMR2255".equals(c1.genuineRetailers.get(0).customerId),
                "SMR2255 is True Retailer #1");

        // 4. Cross-page Dist-to-shadow boundary!
        // Page 1 ends with (Dist) "NORTH DAIRY" -> trailingDistributorName = "north dairy"
        List<UpgradeRules.Card> page1 = Arrays.asList(
                new UpgradeRules.Card("101", "ALPHA SHOP", false, true),
                new UpgradeRules.Card("SM100", "NORTH DAIRY", true, false)
        );
        UpgradeRules.Classification cp1 = UpgradeRules.classifyCards(page1);
        check("north dairy".equals(cp1.trailingDistributorName), "Page 1 detects trailing Dist at bottom");

        // Page 2 starts with (Retailer) "NORTH DAIRY" (shadow!) followed by genuine "VILLAGE SHOP"
        List<UpgradeRules.Card> page2 = Arrays.asList(
                new UpgradeRules.Card("778812", "NORTH DAIRY", false, true),
                new UpgradeRules.Card("ABC-17", "VILLAGE SHOP", false, true),
                new UpgradeRules.Card("9999", "NORTH DAIRY", false, true) // later same-name genuine!
        );
        UpgradeRules.Classification cp2 = UpgradeRules.classifyCardsWithCarryOver(page2, cp1.trailingDistributorName);
        check(cp2.allBlacklistedIds.contains("778812"), "Cross-page immediate shadow 778812 boycotted");
        check(!cp2.allBlacklistedIds.contains("ABC-17"), "Genuine ABC-17 kept");
        check(!cp2.allBlacklistedIds.contains("9999"), "Later same-name genuine 9999 NOT skipped");
        check(cp2.genuineRetailers.size() == 2, "Both ABC-17 and 9999 eligible");

        // Page 2 with DIFFERENT first retailer name -> NOT skipped!
        List<UpgradeRules.Card> page2Diff = Arrays.asList(
                new UpgradeRules.Card("88421", "DIFFERENT SHOP", false, true)
        );
        UpgradeRules.Classification cp2Diff = UpgradeRules.classifyCardsWithCarryOver(page2Diff, cp1.trailingDistributorName);
        check(cp2Diff.genuineRetailers.size() == 1 && "88421".equals(cp2Diff.genuineRetailers.get(0).customerId),
                "Different-name retailer after trailing Dist is genuine");

        // 5. Employee's Chance scatter & Customer Demand pack math
        Map<Integer, Integer> plan = UpgradeRules.generateScatteredPlan("2026-11-20", 10000, 15, 125);
        int sum = 0;
        List<Integer> keys = new ArrayList<>(plan.keySet());
        for (int v : plan.values()) sum += v;
        check(plan.size() == 15 && sum == 10000 && keys.get(keys.size() - 1) > 30, "Scatter plan valid");

        int[] delta = UpgradeRules.resolvePackDelta(1000, 0, 4);
        check(delta != null && delta[0] == 500 && delta[1] == 6, "COW 500 ML 4 -> 6");

        System.out.println("CHECKS " + checks + " passed");
    }
}
