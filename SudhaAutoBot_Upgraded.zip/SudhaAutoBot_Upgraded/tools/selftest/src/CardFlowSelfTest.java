import android.view.accessibility.AccessibilityNodeInfo;
import com.vrksignatures.sudhaautobot.*;
import java.util.*;

/** Runs the production card parser and selector together against synthetic accessibility trees. */
public final class CardFlowSelfTest {
    private static int checks;
    private static void check(boolean ok, String what) {
        checks++; if (!ok) throw new AssertionError(what);
    }
    private static AccessibilityNodeInfo node(String text, int top) {
        AccessibilityNodeInfo n = new AccessibilityNodeInfo();
        n.text = text; n.bounds.set(0, top, 800, top + 30); return n;
    }
    private static void card(AccessibilityNodeInfo root, String type, String label, String id, String name, int top, boolean split) {
        AccessibilityNodeInfo row = node(null, top); row.bounds.set(0, top, 800, top + 95); row.clickable = true;
        AccessibilityNodeInfo a = node("Delivery Point (" + type + ")", top);
        AccessibilityNodeInfo inner = node(null, top); inner.add(a);
        row.add(inner);
        row.add(node(split ? label : label + " " + id, top + 10));
        if (split) row.add(node(id, top + 10));
        row.add(node(name, top + 40));
        root.add(row);
    }
    public static void main(String[] args) {
        AccessibilityNodeInfo root = node(null, 0);
        card(root, "Retailer", "Customer Id:", "SMR2157", "PANDEY G SUDHA MILK PARLOR", 100, false);
        card(root, "Retailer", "Customer ID:", "20173", "Abhishek Enterprises", 200, false);
        card(root, "Retailer", "Customer   id :", "19863", "Lal ji kirana", 300, true);
        card(root, "Retailer", "Customer ID:", "ABC-17", "Other", 400, false);
        List<DistributorBlueprint.CardInfo> cards = DistributorBlueprint.parseVisibleCards(root);
        check(cards.size() == 4, "all four cards parsed, including split label");
        List<String> ids = new ArrayList<>();
        for (DistributorBlueprint.CardInfo c : DistributorBlueprint.classifyOrderedCards(cards).genuineRetailers) ids.add(c.customerId);
        check(ids.equals(Arrays.asList("SMR2157", "20173", "19863", "ABC-17")), "visual order and exact ids: " + ids);
        for (String typed : Arrays.asList("SMR2157", "SMR 2157")) {
            int match = RetailerPolicy.findStartId(ids, typed);
            check(match == 0, "typed start resolves " + typed);
            RetailerSequence.Decision d = new RetailerSequence().decideAnyId(ids, ids.get(match), x -> false);
            check(d.action == RetailerSequence.Action.OPEN && "20173".equals(d.id), "next is 20173");
            check(cards.get(d.index).containerNode == root.getChild(1), "target is the correct card node");
        }
        check(RetailerPolicy.findStartId(Arrays.asList("ABC", "A BC"), "AB C") == -1, "ambiguous whitespace alias rejected");
        check("ABC-17".equals(StartPoint.normalise(" abc-17 ")) && "20173".equals(StartPoint.normalise("20173")), "no prefix or punctuation rewriting");
        check(RetailerPolicy.isValidCustomerId("LONG-IDENTIFIER-0123456789012345678901234567890123456789"), "no artificial id length limit");
        Set<String> marked = new LinkedHashSet<>();
        StartPoint.Seeker seek = new StartPoint.Seeker("SMR 2157", "typed");
        StartPoint.Book oldBook = new StartPoint.Book() {
            public boolean isProcessed(String id) { return marked.contains(id); }
            public String lastHandled() { return "SMR 2157"; }
            public boolean markDoneBefore(String id, String why) { return marked.add(id); }
        };
        seek.seesAnyId(Arrays.asList("OLD"), oldBook);
        seek = seek.withId("SMR2157");
        StartPoint.Book resolvedBook = new StartPoint.Book() {
            public boolean isProcessed(String id) { return marked.contains(id); }
            public String lastHandled() { return "SMR2157"; }
            public boolean markDoneBefore(String id, String why) { return marked.add(id); }
        };
        check(seek.seesAnyId(ids, resolvedBook) == StartPoint.Seeker.Outcome.REACHED && marked.contains("OLD") && !marked.contains("20173"), "alias resolution preserves prior rows, not the next row");
        check(RetailerPolicy.detailsShowsId("Customer Details\nName\nAbhishek (20173)\nDistributor Name (SM65)", "20173"), "exact details header");
        check(!RetailerPolicy.detailsShowsId("Name\nX (120173)\nDistributor Name (20173)", "20173"), "substring and distributor do not verify");
        AccessibilityNodeInfo shadows = node(null, 0);
        card(shadows, "Dist", "Customer Id:", "SM65", "RANJANA YADVENDU", 100, false);
        card(shadows, "Retailer", "Customer ID:", "65", "RANJANA YADVENDU", 200, false);
        card(shadows, "Retailer", "Customer ID:", "OTHER", "Another", 300, false);
        card(shadows, "Retailer", "Customer ID:", "ABCD", "RANJANA YADVENDU", 400, false);
        List<DistributorBlueprint.CardInfo> good = DistributorBlueprint.classifyOrderedCards(DistributorBlueprint.parseVisibleCards(shadows)).genuineRetailers;
        check(good.size() == 2 && good.get(0).customerId.equals("OTHER") && good.get(1).customerId.equals("ABCD"), "only adjacent same-name shadow excluded");
        AccessibilityNodeInfo noValue = node(null, 0);
        AccessibilityNodeInfo incomplete = node(null, 100); incomplete.clickable = true;
        incomplete.add(node("Delivery Point (Retailer)", 100));
        incomplete.add(node("Customer ID:", 110));
        incomplete.add(node("Shop name must not become the ID", 150));
        noValue.add(incomplete);
        check(DistributorBlueprint.parseVisibleCards(noValue).isEmpty(), "missing ID does not become shop name");
        AccessibilityNodeInfo broken = node(null, 0); broken.add(node("Delivery Point (Retailer)", 100));
        check(DistributorBlueprint.visibleAnchorCount(broken) > DistributorBlueprint.parseVisibleCards(broken).size(), "unreadable anchor detected rather than silently skipped");
        System.out.println("== CardFlowSelfTest ==\nALL " + checks + " CHECKS PASSED");
    }
}
