import android.view.accessibility.AccessibilityNodeInfo;
import com.vrksignatures.sudhaautobot.*;
import java.util.*;

/** Runs the production card parser and selector together against synthetic accessibility trees. */
public final class CardFlowSelfTest {
    private static int checks;
    private static void check(boolean ok, String what) {
        checks++; if (!ok) throw new AssertionError(what);
    }
    private static AccessibilityNodeInfo node(String text, int top) {
        AccessibilityNodeInfo n = new AccessibilityNodeInfo();
        n.text = text; n.bounds.set(0, top, 800, top + 30); return n;
    }
    private static void card(AccessibilityNodeInfo root, String type, String label, String id, String name, int top, boolean split) {
        AccessibilityNodeInfo row = node(null, top); row.bounds.set(0, top, 800, top + 95); row.clickable = true;
        AccessibilityNodeInfo a = node("Delivery Point (" + type + ")", top);
        AccessibilityNodeInfo inner = node(null, top); inner.add(a);
        row.add(inner);
        row.add(node(split ? label : label + " " + id, top + 10));
        if (split) row.add(node(id, top + 10));
        row.add(node(name, top + 40));
        root.add(row);
    }
    private static AccessibilityNodeInfo liveCard(AccessibilityNodeInfo list, String type, String id, String name, int top) {
        AccessibilityNodeInfo c = node(null, top); c.viewId = DistributorBlueprint.CARD_ID;
        c.className = "android.widget.FrameLayout"; c.clickable = true; c.bounds.set(0,top,800,top+95);
        c.add(node("Delivery Point", top)); c.add(node("("+type+")",top));
        c.add(node("Customer Id:",top+10)); c.add(node(id,top+10)); c.add(node(name,top+40));
        list.add(c); return c;
    }
    private static List<DistributorBlueprint.CardInfo> livePage(String[][] rows) {
        AccessibilityNodeInfo root = node(null, 0), list = node(null, 0);
        list.viewId = DistributorBlueprint.CUSTOMER_LIST_ID; root.add(list);
        for (int i=0; i<rows.length; i++) liveCard(list,rows[i][0],rows[i][1],rows[i][2],100+i*100);
        return DistributorBlueprint.parseVisibleCards(root);
    }
    public static void main(String[] args) {
        AccessibilityNodeInfo root = node(null, 0);
        card(root, "Retailer", "Customer Id:", "SMR2157", "PANDEY G SUDHA MILK PARLOR", 100, false);
        card(root, "Retailer", "Customer ID:", "20173", "Abhishek Enterprises", 200, false);
        card(root, "Retailer", "Customer   id :", "19863", "Lal ji kirana", 300, true);
        card(root, "Retailer", "Customer ID:", "ABC-17", "Other", 400, false);
        List<DistributorBlueprint.CardInfo> cards = DistributorBlueprint.parseVisibleCards(root);
        check(cards.size() == 4, "all four cards parsed, including split label");
        List<String> ids = new ArrayList<>();
        for (DistributorBlueprint.CardInfo c : DistributorBlueprint.classifyOrderedCards(cards).genuineRetailers) ids.add(c.customerId);
        check(ids.equals(Arrays.asList("SMR2157", "20173", "19863", "ABC-17")), "visual order and exact ids: " + ids);
        for (String typed : Arrays.asList("SMR2157", "SMR 2157")) {
            int match = RetailerPolicy.findStartId(ids, typed);
            check(match == 0, "typed start resolves " + typed);
            RetailerSequence.Decision d = new RetailerSequence().decideAnyId(ids, ids.get(match), x -> false);
            check(d.action == RetailerSequence.Action.OPEN && "20173".equals(d.id), "next is 20173");
            check(cards.get(d.index).containerNode == root.getChild(1), "target is the correct card node");
        }
        check(RetailerPolicy.findStartId(Arrays.asList("ABC", "A BC"), "AB C") == -1, "ambiguous whitespace alias rejected");
        check("ABC-17".equals(StartPoint.normalise(" abc-17 ")) && "20173".equals(StartPoint.normalise("20173")), "no prefix or punctuation rewriting");
        check(RetailerPolicy.isValidCustomerId("LONG-IDENTIFIER-0123456789012345678901234567890123456789"), "no artificial id length limit");
        Set<String> marked = new LinkedHashSet<>();
        StartPoint.Seeker seek = new StartPoint.Seeker("SMR 2157", "typed");
        StartPoint.Book oldBook = new StartPoint.Book() {
            public boolean isProcessed(String id) { return marked.contains(id); }
            public String lastHandled() { return "SMR 2157"; }
            public boolean markDoneBefore(String id, String why) { return marked.add(id); }
        };
        seek.seesAnyId(Arrays.asList("OLD"), oldBook);
        seek = seek.withId("SMR2157");
        StartPoint.Book resolvedBook = new StartPoint.Book() {
            public boolean isProcessed(String id) { return marked.contains(id); }
            public String lastHandled() { return "SMR2157"; }
            public boolean markDoneBefore(String id, String why) { return marked.add(id); }
        };
        check(seek.seesAnyId(ids, resolvedBook) == StartPoint.Seeker.Outcome.REACHED && marked.contains("OLD") && !marked.contains("20173"), "alias resolution preserves prior rows, not the next row");
        check(RetailerPolicy.detailsShowsId("Customer Details\nName\nAbhishek (20173)\nDistributor Name (SM65)", "20173"), "exact details header");
        check(!RetailerPolicy.detailsShowsId("Name\nX (120173)\nDistributor Name (20173)", "20173"), "substring and distributor do not verify");
        AccessibilityNodeInfo shadows = node(null, 0);
        card(shadows, "Dist", "Customer Id:", "SM65", "RANJANA YADVENDU", 100, false);
        card(shadows, "Retailer", "Customer ID:", "65", "RANJANA YADVENDU", 200, false);
        card(shadows, "Retailer", "Customer ID:", "OTHER", "Another", 300, false);
        card(shadows, "Retailer", "Customer ID:", "ABCD", "RANJANA YADVENDU", 400, false);
        List<DistributorBlueprint.CardInfo> good = DistributorBlueprint.classifyOrderedCards(DistributorBlueprint.parseVisibleCards(shadows)).genuineRetailers;
        check(good.size() == 2 && good.get(0).customerId.equals("OTHER") && good.get(1).customerId.equals("ABCD"), "only adjacent same-name shadow excluded");
        AccessibilityNodeInfo noValue = node(null, 0);
        AccessibilityNodeInfo incomplete = node(null, 100); incomplete.clickable = true;
        incomplete.add(node("Delivery Point (Retailer)", 100));
        incomplete.add(node("Customer ID:", 110));
        incomplete.add(node("Shop name must not become the ID", 150));
        noValue.add(incomplete);
        check(DistributorBlueprint.parseVisibleCards(noValue).isEmpty(), "missing ID does not become shop name");
        AccessibilityNodeInfo broken = node(null, 0); broken.add(node("Delivery Point (Retailer)", 100));
        check(DistributorBlueprint.visibleAnchorCount(broken) > DistributorBlueprint.parseVisibleCards(broken).size(), "unreadable anchor detected rather than silently skipped");
        AccessibilityNodeInfo live = node(null,0), list = node(null,0);
        list.viewId = DistributorBlueprint.CUSTOMER_LIST_ID; list.scrollable = true; live.add(list);
        liveCard(list,"Dist","SM65","RANJANA YADVENDU",100);
        liveCard(list,"Retailer","65"," Ranjana  Yadvendu ",200);
        AccessibilityNodeInfo target = liveCard(list,"Retailer","SMR2157","PANDEY",300);
        liveCard(list,"Retailer","20173","Abhishek Enterprises",400);
        liveCard(list,"Retailer","19863","Lal ji kirana",500);
        liveCard(list,"Retailer","19824","ABC Shop",600);
        liveCard(list,"Retailer","ABC-17","Arbitrary ID",700);
        liveCard(live,"Retailer","WRONG","Outside list",800);
        List<DistributorBlueprint.CardInfo> liveCards = DistributorBlueprint.parseVisibleCards(live);
        check(liveCards.size() == 7 && DistributorBlueprint.visibleAnchorCount(live) == 7, "exact card containers under list only");
        check(liveCards.get(2).containerNode == target && liveCards.get(3).boldOrangeName.equals("Abhishek Enterprises"), "clickable card and adjacent name");
        DistributorBlueprint.CardTraversal tracker = new DistributorBlueprint.CardTraversal();
        DistributorBlueprint.Classification first = tracker.observe(liveCards, 1);
        check(first != null && first.genuineRetailers.size() == 4 && first.genuineRetailers.get(0).customerId.equals("SMR2157"), "exclude dist and its same-name shadow");
        List<String> liveIds = new ArrayList<>(); for (DistributorBlueprint.CardInfo c : first.genuineRetailers) liveIds.add(c.customerId);
        for (int i=0; i<3; i++) {
            RetailerSequence.Decision next = new RetailerSequence().decideAnyId(liveIds, liveIds.get(i), x -> false);
            check(next.action == RetailerSequence.Action.OPEN && next.id.equals(liveIds.get(i+1)), "numeric next retailer " + i);
        }
        AccessibilityNodeInfo missing = liveCard(list,"Retailer","","Missing",800);
        missing.add(node("RTR_ROUTE", 850));
        check(DistributorBlueprint.visibleAnchorCount(live) == 8 && DistributorBlueprint.parseVisibleCards(live).size() == 7, "unreadable card counted, not guessed");
        missing.visibleToUser = false;
        AccessibilityNodeInfo legacy = node(null, 0), legacyRow = node(null, 100); legacyRow.clickable=true; legacy.add(legacyRow);
        legacyRow.add(node("Delivery Point",100)); legacyRow.add(node("(Retailer)",100));
        legacyRow.add(node("Customer Id:",110)); legacyRow.add(node("19824",110)); legacyRow.add(node("Lal ji kirana",140));
        check(DistributorBlueprint.parseVisibleCards(legacy).size() == 1 && DistributorBlueprint.visibleAnchorCount(legacy)==1, "split-label fallback within one card");
        tracker = new DistributorBlueprint.CardTraversal();
        check(tracker.observe(livePage(new String[][]{{"Dist","SM65","Shop"}}), 2) != null, "boundary first page");
        DistributorBlueprint.Classification boundary = tracker.observe(livePage(new String[][]{{"Dist","SM65","Shop"},{"Retailer","65","Shop"},{"Retailer","20173","Real"},{"Retailer","19863","Next"}}), 2);
        check(boundary != null && boundary.genuineRetailers.size()==1 && boundary.genuineRetailers.get(0).customerId.equals("20173"), "overlapping boundary shadow skipped and last deferred");
        boundary = tracker.observe(livePage(new String[][]{{"Retailer","65","Shop"},{"Retailer","20173","Real"},{"Retailer","19863","Next"}}), 2);
        check(boundary != null && boundary.genuineRetailers.size()==1 && boundary.genuineRetailers.get(0).customerId.equals("20173"), "shadow remains excluded after dist scrolls away");
        check(tracker.observe(livePage(new String[][]{{"Retailer","65","Shop"},{"Retailer","20173","Real"},{"Retailer","19863","Next"}}), 3).genuineRetailers.size()==1, "shadow remembered across visit");
        check(tracker.observe(livePage(new String[][]{{"Retailer","19824","Unseen"}}), 3) == null, "no overlap fails closed");
        tracker.reset();
        DistributorBlueprint.Classification beforeDist = tracker.observe(livePage(new String[][]{{"Dist","A","A"},{"Retailer","9","Shop"}}), 8);
        check(beforeDist != null && beforeDist.genuineRetailers.isEmpty(), "last retailer held until next card known");
        DistributorBlueprint.Classification afterDist = tracker.observe(livePage(new String[][]{{"Retailer","9","Shop"},{"Dist","B","Shop"}}), 8);
        check(afterDist != null && afterDist.genuineRetailers.isEmpty(), "preceding shadow skipped when distributor appears");
        tracker.reset();
        tracker.observe(livePage(new String[][]{{"Dist","A","A"},{"Retailer","9","Real"}}), 9);
        check(tracker.proveEndForWithheldCard(), "end releases withheld last card");
        check(tracker.observe(livePage(new String[][]{{"Dist","A","A"},{"Retailer","9","Real"}}),9).genuineRetailers.size()==1, "last genuine retailer available after proven end");
        tracker.reset();
        check(tracker.observe(livePage(new String[][]{{"Retailer","65","Shop"}}), 4) == null, "unknown predecessor fails closed");
        tracker.reset(); tracker.observe(livePage(new String[][]{{"Dist","SM65","Shop"},{"Retailer","20173","Real"}}),5);
        check(tracker.observe(livePage(new String[][]{{"Retailer","20173","Other shop"}}),5) == null, "same id different shops fails closed");
        AccessibilityNodeInfo count = node("125",0); count.viewId="in.vasista.suprabhat:id/count"; live.add(count);
        check(AccessibilityTree.customerTotalFromScreen(live)==125, "count by exact live id");
        AccessibilityNodeInfo filter = node("All Distributors",0); filter.viewId=DistributorBlueprint.FILTER_ID; live.add(filter);
        check(DistributorBlueprint.findFilterDropdown(live)[0] == filter, "filter by exact live id");
        AccessibilityNodeInfo popup = node(null,0), menu = node(null,0), option = node("All Distributors",0);
        menu.className="android.widget.ListView"; option.clickable=true; popup.add(menu); menu.add(option);
        check(DistributorBlueprint.findFilterOption(popup)==option, "select filter option only inside popup list");
        liveCard(list,"Retailer","label","All Distributors",900);
        check(DistributorBlueprint.findFilterOption(live)==null, "never select a shop name or spinner as popup option");
        System.out.println("== CardFlowSelfTest ==\nALL " + checks + " CHECKS PASSED");
    }
}
