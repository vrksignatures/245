package android.content;
import java.util.Set;
public interface SharedPreferences {
    boolean getBoolean(String key, boolean def);
    int getInt(String key, int def);
    Set<String> getStringSet(String key, Set<String> def);
    Editor edit();
    interface Editor {
        Editor putBoolean(String key, boolean value);
        Editor putInt(String key, int value);
        Editor putStringSet(String key, Set<String> value);
        Editor clear();
        void apply();
    }
}
